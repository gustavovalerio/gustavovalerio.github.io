﻿---
title: "Obras"
date: 2020-04-04T18:29:37-03:00
draft: false
type: "static"
author: "Gustavo Valério Ferreira"
aliases: [/p/obras.html]
---

![Lira Valeriana](/img/lira-valeriana.jpg)

(2022) A obra pode ser adquirida das seguintes formas:
[Uiclap (Capa Azul)](https://loja.uiclap.com/titulo/ua18995/)
[Uiclap (Capa Vermelha)](https://loja.uiclap.com/titulo/ua18996/)

<br>

![Delírios Circulares](/img/delirios-circulares.png)

(2021) A obra pode ser adquirida nas seguintes plataformas:
[Uiclap](https://loja.uiclap.com/titulo/ua18997/)
[AGBook](https://agbook.com.br/book/370256--Delirios_Circulares)
[Clube dos Autores](https://clubedeautores.com.br/livro/delirios-circulares)

<br>

![Versos Revivalistas](/img/Versos-Revivalistas.png)

A obra está publicada na plataforma Wattpad, e pode ser acessada  [clicando aqui](https://www.wattpad.com/story/216649060-versos-revivalistas).

<br>

Para visualizar todas as obras disponíveis para compra, [clique aqui](https://uiclap.bio/gustavovalerio).
